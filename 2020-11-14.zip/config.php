<?php
	$host['name'] = 'localhost';
	$host['id'] = 'root';
	$host['pw'] = 'root';
	$host['databasename'] = 'koreabtc'; 
	$db = mysql_pconnect($host['name'], $host['id'], $host['pw']) OR die ('������ ���峭 ��.');
	mysql_select_db($host['databasename'], $db);
	mysql_query('set names utf8');

?>