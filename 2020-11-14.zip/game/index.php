﻿<?php
	include('config.php');
	date_default_timezone_set('Asia/Seoul');
	session_start();
	if(isset($_SESSION['email']))
	{
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
	}
?>

<!DOCTYPE html>


<head>
  
 <meta charset=UTF-8" />
<meta name="robots" content="noindex,nofollow"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA Compatible" control="IE=edge,chrome=1" />
<link rel="stylesheet" type="text/css" href="css/table.css" />

  
<script src="https://code.jqury.com/jquery-3.1.1.min.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="./icon.jpg">

<title>MapleStep - 메이플스토리 STEP길드</title>




  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="./css/landing-page.min.css" rel="stylesheet">

  
  <script type="text/javascript" src="//code.jquery.com/jquery.min.js"></script>
  <script>
var timerID;

        window.onload = function() {

        document.getElementById('execute').click();

        }
var timerID;
$(document).ready(function () {
    $('#execute').on('click',function(e){
        e.preventDefault();
        updateData();
    });
    $('#stop').on('click',function(e){
        e.preventDefault();
       clearTimeout(timerID); // 타이머 중지
        $('#showtime').html('');
    });
});

function updateData(){
    $.ajax({
      url: "getserver.php",
      type:"post",
      cache : false,
      success: function(data){ // getserver.php 파일에서 echo 결과값이 data 임
       $('#showtime').html(data);
      }
    });
    timerID = setTimeout("updateData()", 500); // 
}
</script>
  
  
  
  
  
  
  
  

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="../index.php"><img src="./icon.jpg">STEP<img src="./icon.jpg"></a>
					</li>

					<li class="nav-item active">
						<a class="nav-link" href="../game">게임(10초경매)</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../flagcheck.php">플래그인증</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../mileage/">마일리지내역</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../notice/">공지사항</a>
					</li>		
				</ul>
				
				<?php
					if(isset($_SESSION['email']))
					{
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link"><?php echo "<b>{$queryinformation['name']}</b>님";?></a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../mypage" onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=550px,height=700px'); return false;" xss="removed">마이페이지(미제공)</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../logout.php">로그아웃</a>
					</li>
				</ul>	
				<?php
					}
					else
					{		
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link" href="../login.php">로그인</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../join.php">회원가입</a>
					</li>
				</ul>
				<?php
					}
				?>
			</div>
			</nav>
				

  <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
	    
        <div class="col-xl-9 mx-auto">
		<a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		   <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a><br>
	
          <p><span id="showtime"></span></p>
		  
		  
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		  <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a>
		   <a href="./dododo.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="1" value="입 찰 하 기" /></a><br>
		 입찰시 20마일리지가 소모되며 낙찰금앤은 10원씩 증가 됩니다.<br>
			
			입찰 가능 시간(남은시간)안에 입찰을 하지 않을시 마지막에 입찰하신분이 당첨자 입니다.
			
			<br><br>
			에러페이지 발생또는 페이지새로고침이 멈출 경우 F5 새로고침 하시기 바랍니다.
			<br>
			입찰에 사용한 길드 마일리지는 소모됩니다.
			<br>
			1~2초 지연이 되거나 빠를수 있으니 입찰에 참고하시기 바랍니다.<br>
			<br>도박중독 상담 : 1336 / <a href="http://www.kcgp.or.kr">온라인 도박중돔 상담</a>
			<br>
			<a href="../mypage.php"  onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=300px,height=70px'); return false;" xss="removed"><input type="button" id="" value="남은 마일리지 확인"></a><br>
			경매에 사용한 마일리지에 따라 표시되는 색깔이 다릅니다. 최대 6000점 까지<br>
		</div>
		  
		  
        </div>
 
      </div>
	  
    </div>
	
  </header>

  <!-- Icons Grid -->
  <section class="features-icons bg-light text-center">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
            <h3 id="chatLog">STEP 공지사항

	
			</h3>
			<!--
			<?php
					$page = 1;
					$sql1 = mysql_query("select * from rabelitem");
					$row_num = mysql_num_rows($sql1);
					$list = 20;
					$block_ct = 8; 
					$block_num = ceil($page/$block_ct);
					$block_start = (($block_num - 1) * $block_ct) + 1;
					$block_end = $block_start + $block_ct - 1;
					$total_page = ceil($row_num / $list);
					if($block_end > $total_page) $block_end = $total_page;
					$total_block = ceil($total_page/$block_ct);
					$start_num = ($page-1) * $list;
					$sql2 = mysql_query("select * from rabelitem order by count desc limit $start_num, $list"); 
					$i=1;				
					while($board = mysql_fetch_array($sql2))
					{
						
						echo "<p class='lead mb-0'>";
						
						echo "{$i}위 - <a href='./srabel/info.php?id=";
						$i++;
						echo $board['id'];
						echo "' target='_blank'>";
						echo $board['name'];
						echo "</p></a>";	
					}
				?>

!-->
          </div>
        </div>
        <div class="col-lg-4">
          <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
            <h3>마일리지 보유순위</h3>
			<p class="lead mb-0">1.</p>
			<p class="lead mb-0">2</p>			
			<p class="lead mb-0">3</p>
			<p class="lead mb-0">4</p>
			<p class="lead mb-0">5</p>			
            <p class="lead mb-0">6</p>
			<p class="lead mb-0">7</p>
			<p class="lead mb-0">8</p>
			<p class="lead mb-0">9</p>
			<p class="lead mb-0">10</p>
			
          </div>
        </div>
        <div class="col-lg-4">
          <div class="features-icons-item mx-auto mb-0 mb-lg-3">
            <h3>기타</h3>
			<p class="lead mb-0">길드 수로 자동 파티</p>
            <p class="lead mb-0">아케인 심볼 계산기 (준비중)</p>
			<p class="lead mb-0">하이퍼 스탯 계산기 (준비중)</p>
			<p class="lead mb-0">경뿌, 홀리심볼 알리미(준비중)</p>
			<p class="lead mb-0">무토 레시피 (준비중)</p>
			<p class="lead mb-0">링크, 유니온 정보 (준비중)</p>
			<p class="lead mb-0">자동 추첨기 (준비중)</p>
			<a href="http://maple.inven.co.kr/" ><p class="lead mb-0">메이플 인벤</p>
			<a href="http://maple.gg"><p class="lead mb-0">maple.gg</p></a>
          </div>
        </div>
      </div>
    </div>
  </section>



 


  <!-- Footer -->
  <footer class="footer bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
          <ul class="list-inline mb-2">
            <li class="list-inline-item">
              <a href="#">정보</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">오픈채팅문의</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">가이드</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">이용규정</a>
            </li>
          </ul>
          <p class="text-muted small mb-4 mb-lg-0" id="execute">&copy; Maplestep.site 2020. All Rights Reserved.</p>
        </div>
        <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
          <ul class="list-inline mb-0">
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-facebook fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-twitter-square fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fab fa-instagram fa-2x fa-fw"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

