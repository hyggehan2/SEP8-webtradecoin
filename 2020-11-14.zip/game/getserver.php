﻿<?php 
	date_default_timezone_set('Asia/Seoul');
		include("config.php");
		$query = mysql_query("select * from named where idx=1");
		$queryinformation = mysql_fetch_array($query);

		$dfddf= $queryinformation['sum'];
		$leavetime = strtotime("+10 seconds", strtotime($queryinformation['date']));
		
		
		$now = strtotime("Now");
		$sumtime = $leavetime-$now;

		;  
?>

<table border=1 align="center">
	<tr>
				<th><font color="black">당첨예정자</font></th>
				<th align="center" colspan="3"><font color="yellow"><?php echo $queryinformation['name'];?></font></th>
			</tr>
			<tr>
				<th><font color="black">현 재 시 간</font></th>
				<th align="center" colspan="3"><font color="blue"><?php echo date("H시 i 분 s 초", $now); ?></th>
			</tr>
			
			<tr>
				<th><font color="black">입찰가능시간</font></th>
				<th align="center" colspan="3"><font><?php echo date("H시 i 분 s 초", $leavetime); ?><br>까지 입찰가능</th>
			</tr>
			<tr>
				<th><font color="black">남은시간</font></th>
				<th align="center" colspan="3" bgcolor="red">
				
					<?php
					if($now>$leavetime)
					{
						
						
						?>
						
					마감 됨
						
						<?php
					}
					else
					{
						echo date("s 초", $sumtime);
					}
					
					?>
				
				</th>
			</tr>
			<tr>
				<th><font color="black">낙 찰 금 액</font></th>
				<th align="center" colspan="3"><font color="black"><font color="yellow"><?php echo number_format($queryinformation['sum'],0);?> 원</font></th>
			</tr>

		<?php
		$bdbd=1;
		$page=1;
		$sql1 = mysql_query("select * from board");
		$row_num = mysql_num_rows($sql1);
		$list = 15;
		$block_ct = 8; 
		$block_num = ceil($page/$block_ct);
		$block_start = (($block_num - 1) * $block_ct) + 1;
		$block_end = $block_start + $block_ct - 1;
		$total_page = ceil($row_num / $list);
		if($block_end > $total_page) $block_end = $total_page;
		$total_block = ceil($total_page/$block_ct);
		$start_num = ($page-1) * $list;
		$sql2 = mysql_query("select * from board order by idx desc limit $start_num, $list");  
		
	?>
		<div align="center">
			<table align="center" border="1" width="80%" height="72%">
			<tr>
				<th><font color="black">순번</font></th>
				<th><font color="black">닉네임</font></th>
				<th><font color="black">입찰시간</font></th>
				<th><font color="black">경매에 총 사용한 마일리지</font></th>
				
		
			</tr>
			<?php
			while($board = mysql_fetch_array($sql2))
			{
			?>
			<tr align="center">
			
				
				
				<?php
					$query = mysql_query("select * from accounts WHERE name='{$board['name']}'");
					$queryinformation = mysql_fetch_array($query);
					$usekrw = $queryinformation['usekrw']
				
				?>
				
				
				
				
				<?php 
					if($usekrw>=13000)
					{
						$color="6DF2FD";
					}
					elseif($usekrw>=12000)
					{
						$color="AF8F5C";
					}
					elseif($usekrw>=11000)
					{
						$color="7AAB71";
					}
					elseif($usekrw>=10000)
					{
						$color="7A6E9E";
					}
					elseif($usekrw>=9000)
					{
						$color="5CB45B";
					}
					elseif($usekrw>=7000)
					{
						$color="848A44";
					}
					elseif($usekrw>=6000)
					{
						$color="red";
					}
					elseif($usekrw>=5000)
					{
						$color="#FF00FF";
					}
					elseif($usekrw>=4000)
					{
						$color="#50fd50";
					}
					elseif($usekrw>=3000)
					{
						$color="yellow";
					}
					elseif($usekrw>=2000)
					{
						$color="#FFA500";
					}
					elseif($usekrw>=1000)
					{
						$color="brown";
					}
					else
					{
						$color="black";
					}
				
				?>
				
				
				
				<td><font color="<?php echo $color;?>"><?php echo $bdbd; $bdbd+=1;?></font></td>
				<td><font color="<?php echo $color;?>"><?php echo $board['name'];?></font></td>
				<td><font color="<?php echo $color;?>"><?php echo $board['datem'];?></font></td>				
				<td><font color="<?php echo $color;?>"><?php echo $usekrw;?></font></td>
			</tr>
			
		
			<?php
		}
			?>

</table>
<b>낙찰 금액 : <?php echo number_format($dfddf,0);?> 메소</b><br>
이번 상품 : 동글이 안경(or9억)<br>
2시 시작 하고 자러 갑니다~~~<br>