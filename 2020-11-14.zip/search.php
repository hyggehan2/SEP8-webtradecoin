﻿<?php
	include('./config.php');
	date_default_timezone_set('Asia/Seoul');
	session_start();
	if(isset($_SESSION['email']))
	{
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="shortcut icon" type="image/x-icon" href="../icon.ico">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Maplesr - 메이플 스라벨 마라벨 시세 차트 정보 제공 사이트</title>

  <!-- Bootstrap core CSS -->
  <link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="./vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="./vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="./css/landing-page.min.css" rel="stylesheet">
  <script src="https://www.google.com/recaptcha/api.js?render=6Lf3TPgUAAAAADDvbBSKzd56mAGeu29mGP1Hjo5F"></script>
 
  
  

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="./index.php">maplesr.com</a>
					</li>

					<li class="nav-item active">
						<a class="nav-link" href="./srabel.php#srabel">스라벨</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../mrabel/">마라벨</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../myasset/">내 자산</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../board/">자유게시판</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../notice/">공지사항</a>
					</li>			
				</ul>
				
				<?php
					if(isset($_SESSION['email']))
					{
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link"><?php echo "<b>{$queryinformation['name']}</b>님";?></a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="./mypage" onclick="window.open(this.href, '', 'resizable=no,status=no,location=yes,toolbar=yes,menubar=no,fullscreen=no,scrollbars=no,dependent=no,width=550px,height=700px'); return false;" xss="removed">마이페이지</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../logout.php">로그아웃</a>
					</li>
				</ul>	
				<?php
					}
					else
					{		
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link" href="../login.php">로그인</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../join.php">회원가입</a>
					</li>
				</ul>
				<?php
					}
				?>
			</div>
			</nav>
				
<header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
	    
         <div class="col-xl-9 mx-auto">
		<br>
		<br>
          <h1 class="mb-5">Maplesr.com</h1>
		  
        </div>
        <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
          <form action="/search.php" method="GET">
            <div class="form-row">
              <div class="col-12 col-md-9 mb-2 mb-md-0">
                <input type="text" id="name" name="name" class="form-control form-control-lg" placeholder="조회 하실 아이템명을 입력하여주세요." required autofocus>
              </div>
              <div class="col-12 col-md-3">
                <button type="submit" class="btn btn-block btn-lg btn-primary">검색</button>
              </div>
			 
            </div>
          </form>
		  <br>
		   <h3>'
		  <?php
				if(isset($_GET['name']))
				{
					$namename = mysql_real_escape_string($_GET['name']);
					echo $namename;
				}
			?>' &nbsp검색결과
			</h3>
        </div>
      </div>
	  
    </div>
	
  </header>

  <section class="features-icons bg-light text-center">
    <div class="container" id='srabel'>
      <div class="row">
			<table class="table">
				<thead>
					<tr>
						<th>아이템명</th>
						<th>기수</th>
						<th>최근 가격</th>
					</tr>
				<?php
				
					if(isset($_GET['name']))
					{
						
						$sql2 = mysql_query("select * from rabelitem where replace(name,' ','') like '%$namename%' order by number desc");
						while($board = mysql_fetch_array($sql2))
						{
							echo "<tr><td><a href='./srabel/info.php?id={$board['id']}'>{$board['name']}</a></td><td>{$board['number']}</td><td>{$board['price']}억</td></tr>";
						}
					}
				?>
				</thead>
			</table>
			
        
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
          <ul class="list-inline mb-2">
            <li class="list-inline-item">
              <a href="#">정보</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">고객센터</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">가이드</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">이용규정</a>
            </li>
          </ul>
          <p class="text-muted small mb-4 mb-lg-0">&copy; Maplesr.com 2019. All Rights Reserved.</p>
        </div>
        <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
          <ul class="list-inline mb-0">
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-facebook fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-twitter-square fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fab fa-instagram fa-2x fa-fw"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
