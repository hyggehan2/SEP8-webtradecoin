﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="ko" xml:lang="ko">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
		<meta name="viewport" content="initial-scale=1.0; maximum-scale=0.75; minimum-scale=1.0; user-scalable=1;width=device-width;"/>
	<div align="center">
	</head>
	<body>
		<?php
		include('../config.php');
			date_default_timezone_set('Asia/Seoul');
			
			$name = $_POST['name'];
			$price = $_POST['price'];
			$date = $_POST['date'];
			$password = mysql_real_escape_string($_POST['password']);
			
			
			if($password=="7032")
			{
				$join = 'INSERT INTO rabelprice (name, price, date, ban) VALUES ("'.mysql_real_escape_string($name).'", "'.mysql_real_escape_string($price).'", "'.mysql_real_escape_string($date).'", "0")';
				$updatepassword = mysql_query("update rabelitem set price='".mysql_real_escape_string($price)."' where name='".mysql_real_escape_string($name)."'");
				
				
				
				mysql_query($join) OR die (mysql_error());
				echo "<script>alert('입력 완료 시세 반영 확인')</script>";
				echo "<meta http-equiv=refresh content='0 url=./index.php?name={$name}&price={$price}&date={$date}&password={$password}'>";
			
			
			}
			else
			{
				echo "<script>alert('비밀번호를 확인하여 주세요.')</script>";
				echo "<meta http-equiv=refresh content='0 url=./index.php?name={$name}&price={$price}&date={$date}&password={$password}'>";
			}
		

		?>
	</body>
</html>
0