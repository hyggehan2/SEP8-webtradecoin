﻿<?php
	session_start();
	if(isset($_GET['id']))
	{
		include "../config.php";
		$id = mysql_real_escape_string($_GET['id']);
		
		
			
				
				
		$query = mysql_query("select * from rabelprice WHERE id='$id'");
		$queryinformation = mysql_fetch_array($query);
		
		
		echo "<script>alert('삭제되었습니다.')</script>";
		$sql = mysql_query("delete from rabelprice where id='$id';");
		echo "<meta http-equiv=refresh content='0 url=./index.php?name={$queryinformation['name']}'>";
	}
		
?>
