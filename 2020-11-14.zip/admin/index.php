﻿<html>
	
	<?php
		
		if(isset($_GET['date']))
		{
			$date = $_GET['date'];
		}
		else
		{
			$date = 0;
		}
		
		
		if(isset($_GET['name']))
		{
			include('../config.php');
			$name = mysql_real_escape_string($_GET['name']);			
		}
		else
		{
			$name = "";
		}
		
		
		if(isset($_GET['price']))
		{
			$price = $_GET['price'];
		}
		else
		{
			$price = "";
		}
		
		if(isset($_GET['password']))
		{
			$password = $_GET['password'];
		}
		else
		{
			$password = "";
		}
		
		
		
		
	
	?>
	<head>
		<title>maplesr.com 스라벨입력기</title>
		<meta charset="UTF-8">
		<link rel="shortcut icon" type="image/x-icon" href="./icon.ico">
		<script src='https://www.google.com/recaptcha/api.js'></script>
		<meta name="viewport" content="width=device-width", initial-scale="1">
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
		<script src="../js/bootstrap.js"></script>
		<link href="https://netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<script src="https://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
		<link rel="shortcut icon" type="image/x-icon" href="./icon.ico">
		
	</head>
	<body>
		<div class="container">
			<div class="row vertical-offset-100">
				<div class="col-md-4 col-md-offset-4">
					<div class="panel panel-default">
						<div class="panel-heading">                                
							<div class="row-fluid user-row" style="background-color:white;">
								<img src="../logo.png" class="img-responsive" alt="Conxole Admin" style="background-color:white;">
							</div>
						</div>
						<div class="panel-body">
							<form action="./join_do.php" method="POST" accept-charset="UTF-8" role="form" class="form-signin">
								<fieldset>
									<label class="panel-login">
										<div class="login_result">Maplesr.com 스라벨 입력</div>
									</label>
									<input type="date" class="form-control" id="date" name="date" maxlength="30"  value="<?php echo $date; ?>" required autofocus>
									<input type="list" class="form-control" id="name" name="name" maxlength="30" placeholder="아이템 명" value="<?php echo $name; ?>" required autofocus>
									<input type="text" class="form-control" id="price" name="price" maxlength="30" placeholder="가격"  value="<?php echo $price; ?>" required>
									<input type="password" class="form-control" id="password" name="password" maxlength="30" placeholder="비밀번호"  value="<?php echo $password; ?>" required>
									
									<br>
								</fieldset>
								<input class="btn btn-lg btn-success btn-block" type="submit" id="login" value="입력 »">
							</form>	
						</div>
						
						<?php
							if(isset($_GET['name']))
							{
							
								$page = 1;
								$sql1 = mysql_query("select * from rabelprice where name='".$name."'");
								$row_num = mysql_num_rows($sql1);
								$list = 20;
								$block_ct = 8; 
								$block_num = ceil($page/$block_ct);
								$block_start = (($block_num - 1) * $block_ct) + 1;
								$block_end = $block_start + $block_ct - 1;
								$total_page = ceil($row_num / $list);
								if($block_end > $total_page) $block_end = $total_page;
								$total_block = ceil($total_page/$block_ct);
								$start_num = ($page-1) * $list;
								$sql2 = mysql_query("select * from rabelprice where name='".$name."'  order by date desc limit $start_num, $list"); 
								
								
								while($board = mysql_fetch_array($sql2))
								{
									echo "{$board['date']} {$board['name']} {$board['price']} <a href='./delete_ok.php?id={$board['id']}'>삭제</a><br>";
								}
								
								
								
							}
							else
							{
								
							}

						
						
						?>
						
					</div>
				</div>
			</div>
		</div>

		
	</body>
</html>