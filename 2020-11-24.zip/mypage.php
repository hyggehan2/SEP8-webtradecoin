﻿<?php
	include('config.php');
	date_default_timezone_set('Asia/Seoul');
	session_start();
	if(isset($_SESSION['email']))
	{
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
?>
남은 마일리지는 
<?php
		echo $queryinformation['krw']; 
?>

입니다.

<?php
	}
	
	else
	{
		echo "로그인후 이용해주세요";
	}
?>
<br>
마일리지사용에 따른 등급<br>
1000~6000점 사용 총 7등급


