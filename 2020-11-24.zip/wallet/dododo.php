﻿<?php
	
	session_start();
	if(isset($_SESSION['email']))
	{
		date_default_timezone_set('Asia/Seoul');
		include("config.php");
		
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
		
		
		
		
		$query = mysql_query("select * from named WHERE title=123");
		$time = mysql_fetch_array($query);
		
		
		$leavetime = strtotime("+10 seconds", strtotime($time['date']));
		
		$now =  strtotime("Now");
		
	
		if($leavetime>=$now)
		{
			$ssum = 20;
			if($queryinformation['krw']>=$ssum)
			{
				$sumdo = $queryinformation['krw']-$ssum;
				$usekrw = $queryinformation['usekrw']+$ssum;
				$updatepassword2 = mysql_query("update accounts set krw='".mysql_real_escape_string($sumdo)."' where email='".mysql_real_escape_string($_SESSION['email'])."'");
				$updatepassword2 = mysql_query("update accounts set usekrw='".mysql_real_escape_string($usekrw)."' where email='".mysql_real_escape_string($_SESSION['email'])."'");
				$ttile= "123";
				$sumsumsum = $time['sum']+10;
				$datedo = date("Y-m-d H:i:s");
				
				
				
				
				
				$named = mysql_query("update named set date='".$datedo."' where title='".$ttile."'");
				$named = mysql_query("update named set name='".$queryinformation['name']."' where title='".$ttile."'");
				$named = mysql_query("update named set sum='".$sumsumsum."' where title='".$ttile."'");
		
				$intxid = mysql_query('INSERT INTO board (name, datem, krw) VALUES ("'.$queryinformation['name'].'",  "'.$datedo.'", "'.$sumdo.'")');

				
				echo("<script>self.close()</script>");
				
				
			}
			else
			{
				echo "<script>alert('마일리지가부족합니다.')</script>";
				echo("<script>self.close()</script>");
				
			}
			
		}
		else
		{
			echo "<script>alert('입찰가능한 시간이 아닙니다.')</script>";
			echo("<script>self.close()</script>");
			
		}
		

	
	
	}
	else 
	{
		echo "<script>alert('로그인 후 시도하여 주세요.')</script>";
		echo("<script>self.close()</script>");
		
	}
		
	
?>
<html>
<head>

</head>




</html>