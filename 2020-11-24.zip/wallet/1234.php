﻿
<?php

    $time = date("H:m:s");

    echo $time;

?>