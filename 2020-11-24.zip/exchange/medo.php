﻿<?php
	session_start();
	if(isset($_SESSION['email']))
	{
		
		include("../config.php");
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
		$query = mysql_query("select * from wallet WHERE id='{$queryinformation['id']}'");
		$wallet = mysql_fetch_array($query);
		
		
		
				$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.upbit.com/v1/orderbook?markets=krw-btc");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$upbitbtc = curl_exec($ch);
	curl_close($ch);
	$btc1 = explode('{"ask_price":', $upbitbtc);
	$btc2 = explode('"bid_price":', $upbitbtc);
	$btc11 = explode('"ask_size":', $upbitbtc);
	$btc22 = explode('"bid_size":', $upbitbtc);
	
	for($i=1;$i<=10;$i++)
	{
		$sell[$i] =explode(",",$btc1[$i])[0];
	}
	
	for($i=1;$i<=10;$i++)
	{
		$buy[$i] = explode(",",$btc2[$i])[0];
	}
	
	for($i=1;$i<=10;$i++)
	{
		$sellamount[$i] =explode(",",$btc11[$i])[0];
	}
	
	for($i=1;$i<=10;$i++)
	{
		$buyamount[$i] =explode("}",$btc22[$i])[0];
		$exchangname[$i]= "업비트";
		$exchangsellname[$i]="업비트";
		
		$exchangeprice[$i]=$buy[$i];
		
		$exchangbuyamount[$i] = $buyamount[$i];
		$exchangsellprice[$i] = $sell[$i];
		$exchangsellamount[$i] = $sellamount[$i];
	}
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.bithumb.com/public/orderbook/btc_krw");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$bitbtc = curl_exec($ch);
	curl_close($ch);
	
	$btc1 = explode('asks', $bitbtc);
	$bithumbbtc = explode('"price":"', $btc1[0]);
	$btc111 = explode('"quantity":"', $btc1[0]);
	$bithumbs = explode('"price":"', $btc1[1]);
	$bithumbsm = explode('"quantity":"', $btc1[1]);
	for($i=1;$i<=10;$i++)
	{
		$bithumbbuy[$i]= explode('"',$bithumbbtc[$i])[0];
		$bithumbbuyamount[$i]= explode('"',$btc111[$i])[0];
		$bithumbsell[$i]= explode('"',$bithumbs[$i])[0];
		$bithumbsellamount[$i]= explode('"',$bithumbsm[$i])[0];
		$exchangname[$i+10]="빗  썸";
		$exchangsellname[$i+10]="빗  썸";
		$exchangeprice[$i+10]=$bithumbbuy[$i];
		$exchangbuyamount[$i+10] = $bithumbbuyamount[$i];
		$exchangsellprice[$i+10] = $bithumbsell[$i];
		$exchangsellamount[$i+10] = $bithumbsellamount[$i];
	}
	
	
	
	
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.coinone.co.kr/orderbook/");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$coinone = curl_exec($ch);
	curl_close($ch);
	
	
	$btc1 = explode('ask', $coinone);
	$cc1 = explode('"price":"', $btc1[0]);
	$cc2 = explode('qty":"', $btc1[0]);
	$cc3 = explode('"price":"', $btc1[1]);
	$cc4 = explode('qty":"', $btc1[1]);
	
	for($i=1;$i<=10;$i++)
	{
		$coinonebuy[$i]= explode('"',$cc1[$i])[0];
		$coinonebuyamount[$i]= explode('"',$cc2[$i])[0];
		$coinonesell[$i]= explode('"',$cc3[$i])[0];
		$coinonesellamount[$i]= explode('"',$cc4[$i])[0];
		
		$exchangname[$i+20]="코인원";
		$exchangsellname[$i+20]="코인원";
		$exchangeprice[$i+20]=$coinonebuy[$i];
		$exchangbuyamount[$i+20] = $coinonebuyamount[$i];
		$exchangsellprice[$i+20] = $coinonesell[$i];
		$exchangsellamount[$i+20] = $coinonesellamount[$i];
	}
	for($i = 1 ; $i <= 30 ; $i ++) 
	{
		for($j = $i+1 ; $j < 30 ; $j ++) 
		{
			if($exchangeprice[$i] < $exchangeprice[$j]) 
			{
	
							$temp =$exchangeprice[$j];
				$exchangeprice[$j] = $exchangeprice[$i];
				$exchangeprice[$i] = $temp;
				
				$temp =$exchangbuyamount[$j];
				$exchangbuyamount[$j] = $exchangbuyamount[$i];
				$exchangbuyamount[$i] = $temp;
				
				
				$temp =$exchangname[$j];
				$exchangname[$j] = $exchangname[$i];
				$exchangname[$i] = $temp;
				
				
			}
		}
    }
	
	for($i = 1 ; $i <= 30 ; $i ++) 
	{
		for($j = $i+1 ; $j < 30 ; $j ++) 
		{
			if($exchangsellprice[$i] > $exchangsellprice[$j]) 
			{
	
				$temp =$exchangsellprice[$j];
				$exchangsellprice[$j] = $exchangsellprice[$i];
				$exchangsellprice[$i] = $temp;
				
				$temp =$exchangsellamount[$j];
				$exchangsellamount[$j] = $exchangsellamount[$i];
				$exchangsellamount[$i] = $temp;
				
				
				$temp =$exchangsellname[$j];
				$exchangsellname[$j] = $exchangsellname[$i];
				$exchangsellname[$i] = $temp;
				
				
			}
		}
    }
	
/*
	$btc1 = explode('ask', $korbit);
	$cc1 = explode('["', $btc1[0]);
	$cc2 = explode(',"', $btc1[0]);
	
	
	// $cc3 = explode('["', $btc1[1]);
	// $cc4 = explode(',"', $btc1[1]);
	
	
	for($i=1;$i<=10;$i++)
	{
		$ii=$i*2-1;
		$korbitbuy[$i]= explode('"',$cc1[$i])[0];
		$korbitbuyamount[$i]= explode('"',$cc2[$ii])[0];
		// $korbitsell[$i]= explode('"',$cc3[$i])[0];
		// $korbitsellamount[$i]= explode('"',$cc4[$ii])[0];
	}
	
	
	
	
	
	// 빗썸 https://api.bithumb.com/public/orderbook/btc_krw
	// 코인원 https://api.coinone.co.kr/orderbook/
	// 코빗  https://api.korbit.co.kr/v1/orderbook
*/
		
		
		
		
	$possiblebtc = $wallet['krwamount']/$exchangsellprice[1];	
		

		
		
		
	}
	else 
	{
		echo "<script>alert('로그인 후 시도하여 주세요.')</script>";
		echo "<meta http-equiv=refresh content='0 url=../login.php'>";
		exit();
	}
	
	
	if(isset($_POST['btcamount']))
	{
	}
	else
	{
		echo "<script>alert('비정상 적인 접근입니다.')</script>";
		echo "<meta http-equiv=refresh content='0 url=./index.php'>";
		exit();
	}
	
	
	$date = date("Y-m-d H:i:s");
	$btcamount = $_POST['btcamount'];

	
	$btckrw= number_format($exchangeprice[1]);
	$sum =$btcamount * $exchangeprice[1];
	

	
	if($btcamount <=0)
	{
		echo "<script>alert('0보다 작은 값은 입력 할 수 없습니다.')</script>";
		echo "<meta http-equiv=refresh content='0 url=./index.php'>";
		exit();
	}
	
	if($wallet['btcamount']<$btcamount)
	{
		echo "<script>alert('매도하려는 비트코인이 부족 합니다.')</script>";
		echo "<meta http-equiv=refresh content='0 url=./index.php'>";
		exit();
	}
	
	

		$accountkrw = $wallet['krwamount'] + $sum;
		
		$accountbtc = $wallet['btcamount'] - $btcamount;
		
		
		$updatekrw = mysql_query("update wallet set krwamount='".$accountkrw."' where id='".$queryinformation['id']."'");
		$updatebtc = mysql_query("update wallet set btcamount='".$accountbtc."' where id='".$queryinformation['id']."'");
		$intxid = mysql_query('INSERT INTO txid (email, type, krwamount, krwsum, ing, ledger, changemoney, date, btcamount, changebtc, btcsum, memo) VALUES ("'.$_SESSION['email'].'", "KRW-BTC", "'.mysql_real_escape_string($sum).'", "'.mysql_real_escape_string($sum).'", "3", "매도-BTC", "'.mysql_real_escape_string($accountkrw).'", "'.$date.'", "-'.mysql_real_escape_string($btcamount).'", "'.mysql_real_escape_string($accountbtc).'", "-'.mysql_real_escape_string($btcamount).'", "'.$sum.'원/'.mysql_real_escape_string($btcamount).'BTC")');
		echo "<script>alert('$sum 원에 $btcamount BTC가 매도 되었습니다.')</script>";
		echo "<meta http-equiv=refresh content='0 url=./index.php'>";
		exit();
	


?>
<html>
	<head>
	</head>
	<body>
	</body>
</html>