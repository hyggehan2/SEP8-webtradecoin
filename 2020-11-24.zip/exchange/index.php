﻿<?php
	include('config.php');
	date_default_timezone_set('Asia/Seoul');
	session_start();
	if(isset($_SESSION['email']))
	{
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
		$query = mysql_query("select * from wallet WHERE id='{$queryinformation['id']}'");
		$wallet = mysql_fetch_array($query);
		
		
			$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.upbit.com/v1/orderbook?markets=krw-btc");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$upbitbtc = curl_exec($ch);
	curl_close($ch);
	$btc1 = explode('{"ask_price":', $upbitbtc);
	$btc2 = explode('"bid_price":', $upbitbtc);
	$btc11 = explode('"ask_size":', $upbitbtc);
	$btc22 = explode('"bid_size":', $upbitbtc);
	
	for($i=1;$i<=10;$i++)
	{
		$sell[$i] =explode(",",$btc1[$i])[0];
	}
	
	for($i=1;$i<=10;$i++)
	{
		$buy[$i] = explode(",",$btc2[$i])[0];
	}
	
	for($i=1;$i<=10;$i++)
	{
		$sellamount[$i] =explode(",",$btc11[$i])[0];
	}
	
	for($i=1;$i<=10;$i++)
	{
		$buyamount[$i] =explode("}",$btc22[$i])[0];
		$exchangname[$i]= "업비트";
		$exchangsellname[$i]="업비트";
		
		$exchangeprice[$i]=$buy[$i];
		
		$exchangbuyamount[$i] = $buyamount[$i];
		$exchangsellprice[$i] = $sell[$i];
		$exchangsellamount[$i] = $sellamount[$i];
	}
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.bithumb.com/public/orderbook/btc_krw");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$bitbtc = curl_exec($ch);
	curl_close($ch);
	
	$btc1 = explode('asks', $bitbtc);
	$bithumbbtc = explode('"price":"', $btc1[0]);
	$btc111 = explode('"quantity":"', $btc1[0]);
	$bithumbs = explode('"price":"', $btc1[1]);
	$bithumbsm = explode('"quantity":"', $btc1[1]);
	for($i=1;$i<=10;$i++)
	{
		$bithumbbuy[$i]= explode('"',$bithumbbtc[$i])[0];
		$bithumbbuyamount[$i]= explode('"',$btc111[$i])[0];
		$bithumbsell[$i]= explode('"',$bithumbs[$i])[0];
		$bithumbsellamount[$i]= explode('"',$bithumbsm[$i])[0];
		$exchangname[$i+10]="빗  썸";
		$exchangsellname[$i+10]="빗  썸";
		$exchangeprice[$i+10]=$bithumbbuy[$i];
		$exchangbuyamount[$i+10] = $bithumbbuyamount[$i];
		$exchangsellprice[$i+10] = $bithumbsell[$i];
		$exchangsellamount[$i+10] = $bithumbsellamount[$i];
	}
	
	
	
	
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.coinone.co.kr/orderbook/");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$coinone = curl_exec($ch);
	curl_close($ch);
	
	
	$btc1 = explode('ask', $coinone);
	$cc1 = explode('"price":"', $btc1[0]);
	$cc2 = explode('qty":"', $btc1[0]);
	$cc3 = explode('"price":"', $btc1[1]);
	$cc4 = explode('qty":"', $btc1[1]);
	
	for($i=1;$i<=10;$i++)
	{
		$coinonebuy[$i]= explode('"',$cc1[$i])[0];
		$coinonebuyamount[$i]= explode('"',$cc2[$i])[0];
		$coinonesell[$i]= explode('"',$cc3[$i])[0];
		$coinonesellamount[$i]= explode('"',$cc4[$i])[0];
		
		$exchangname[$i+20]="코인원";
		$exchangsellname[$i+20]="코인원";
		$exchangeprice[$i+20]=$coinonebuy[$i];
		$exchangbuyamount[$i+20] = $coinonebuyamount[$i];
		$exchangsellprice[$i+20] = $coinonesell[$i];
		$exchangsellamount[$i+20] = $coinonesellamount[$i];
	}
	for($i = 1 ; $i <= 30 ; $i ++) 
	{
		for($j = $i+1 ; $j < 30 ; $j ++) 
		{
			if($exchangeprice[$i] < $exchangeprice[$j]) 
			{
	
							$temp =$exchangeprice[$j];
				$exchangeprice[$j] = $exchangeprice[$i];
				$exchangeprice[$i] = $temp;
				
				$temp =$exchangbuyamount[$j];
				$exchangbuyamount[$j] = $exchangbuyamount[$i];
				$exchangbuyamount[$i] = $temp;
				
				
				$temp =$exchangname[$j];
				$exchangname[$j] = $exchangname[$i];
				$exchangname[$i] = $temp;
				
				
			}
		}
    }
	
	for($i = 1 ; $i <= 30 ; $i ++) 
	{
		for($j = $i+1 ; $j < 30 ; $j ++) 
		{
			if($exchangsellprice[$i] > $exchangsellprice[$j]) 
			{
	
				$temp =$exchangsellprice[$j];
				$exchangsellprice[$j] = $exchangsellprice[$i];
				$exchangsellprice[$i] = $temp;
				
				$temp =$exchangsellamount[$j];
				$exchangsellamount[$j] = $exchangsellamount[$i];
				$exchangsellamount[$i] = $temp;
				
				
				$temp =$exchangsellname[$j];
				$exchangsellname[$j] = $exchangsellname[$i];
				$exchangsellname[$i] = $temp;
				
				
			}
		}
    }
	
/*
	$btc1 = explode('ask', $korbit);
	$cc1 = explode('["', $btc1[0]);
	$cc2 = explode(',"', $btc1[0]);
	
	
	// $cc3 = explode('["', $btc1[1]);
	// $cc4 = explode(',"', $btc1[1]);
	
	
	for($i=1;$i<=10;$i++)
	{
		$ii=$i*2-1;
		$korbitbuy[$i]= explode('"',$cc1[$i])[0];
		$korbitbuyamount[$i]= explode('"',$cc2[$ii])[0];
		// $korbitsell[$i]= explode('"',$cc3[$i])[0];
		// $korbitsellamount[$i]= explode('"',$cc4[$ii])[0];
	}
	
	
	
	
	
	// 빗썸 https://api.bithumb.com/public/orderbook/btc_krw
	// 코인원 https://api.coinone.co.kr/orderbook/
	// 코빗  https://api.korbit.co.kr/v1/orderbook
*/
		
		
		
		
	$possiblebtc = $wallet['krwamount']/$exchangsellprice[1];	
		

		
		
	}
	else
	{
		echo "<script>alert('로그인 후 이용가능합니다.')</script>";
		echo "<meta http-equiv=refresh content='0 url=../login.php'>";
		exit();
	}
?>

<!DOCTYPE html>


<head>
  
 <meta charset=UTF-8" />
<meta name="robots" content="noindex,nofollow"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA Compatible" control="IE=edge,chrome=1" />
<link rel="stylesheet" type="text/css" href="css/table.css" />

  
<script src="https://code.jqury.com/jquery-3.1.1.min.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="./icon.jpg">

<title>프로젝트e.com</title>




  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="./css/landing-page.min.css" rel="stylesheet">

  
  <script type="text/javascript" src="//code.jquery.com/jquery.min.js"></script>
  <script>
var timerID;

        window.onload = function() {

        document.getElementById('execute').click();

        }
var timerID;



$(document).ready(function () {
    $('#execute').on('click',function(e){
        e.preventDefault();
        updateData();
    });
    $('#stop').on('click',function(e){
        e.preventDefault();
       clearTimeout(timerID); // 타이머 중지
        $('#showtime').html('');
    });
});




function updateData(){
    $.ajax({
      url: "getserver.php",
      type:"post",
      cache : false,
      success: function(data){ // getserver.php 파일에서 echo 결과값이 data 임
       $('#showtime').html(data);
      }
    });
    timerID = setTimeout("updateData()", 500); // 
}













</script>
  
  
  
  
  
  
  
  

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="../index.php"><img src="./icon.jpg">프로젝트e.com<img src="./icon.jpg"></a>
					</li>

					<li class="nav-item active">
						<a class="nav-link" href="../exchange">거래소</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../wallet">지갑관리</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../txid/">거래내역</a>
					</li>	
				</ul>
				
				<?php
					if(isset($_SESSION['email']))
					{
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link"><?php echo "<b>{$queryinformation['name']}</b>님";?></a>
					</li>
					
					<li class="nav-item active">
						<a class="nav-link" href="../logout.php">로그아웃</a>
					</li>
				</ul>	
				<?php
					}
					else
					{		
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link" href="../login.php">로그인</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../join.php">회원가입</a>
					</li>
				</ul>
				<?php
					}
				?>
			</div>
			</nav>
				

  <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
	    
        <div class="col-xl-9 mx-auto">

          <p><span id="showtime"></span></p>
		  
		  거래가능 KRW : <?php echo number_format($wallet['krwamount']);?> 원<BR>
		  거래가능 BTC : <?php echo number_format($wallet['btcamount'],4);?> BTC<BR><BR>
		  <form action="./mesu.php" method="POST">
         <input type="number" id="btcamount" onchange="mountbtc();" onkeyup="mountbtc();"   name="btcamount" size="8" min="0.0001" step="0.0001"><button>개 매수하기</button>
		 
		 </form> 
		 <br><br>
		 <form action="./medo.php" method="POST">
         <input type="number" id="btcamount" onchange="mountbtc();" onkeyup="mountbtc();"    name="btcamount" size="8" min="0.0001" step="0.0001"><button>개 매도하기</button>
		 </form>
		 <br>
				</div>
		  
		  
        </div>
 
      </div>
	  
    </div>
	
  </header>

 

 


  <!-- Footer -->
  <footer class="footer bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
          <ul class="list-inline mb-2">
            <li class="list-inline-item">
              <a href="#">소프트웨어공학론</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">김규환 박종훈 강 일 위안펑</a>
            </li>
          </ul>
          <p class="text-muted small mb-4 mb-lg-0" id="execute">&copy; 프로젝트e.com 2020. All Rights Reserved.</p>
        </div>
        <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
          <ul class="list-inline mb-0">
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-facebook fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-twitter-square fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fab fa-instagram fa-2x fa-fw"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

