﻿<?php
	session_start();
	if(isset($_SESSION['email']))
	{
		include('config.php');
		date_default_timezone_set('Asia/Seoul');
		$query = mysql_query("select * from accounts WHERE email='{$_SESSION['email']}'");
		$queryinformation = mysql_fetch_array($query);
		if(isset($_GET['page']))
				{
					$page = $_GET['page'];
				}
				else
				{
					$page = 1;
				}


		
		
	}
	else
	{
		echo "<script>alert('로그인 후 이용가능합니다.')</script>";
		echo "<meta http-equiv=refresh content='0 url=../login.php'>";
		exit();
	}
?>

<!DOCTYPE html>


<head>
  
 <meta charset=UTF-8" />
<meta name="robots" content="noindex,nofollow"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA Compatible" control="IE=edge,chrome=1" />
<link rel="stylesheet" type="text/css" href="css/table.css" />

  
<script src="https://code.jqury.com/jquery-3.1.1.min.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="./icon.jpg">

<title>프로젝트e.com</title>




  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="./css/landing-page.min.css" rel="stylesheet">

  
  <script type="text/javascript" src="//code.jquery.com/jquery.min.js"></script>
  <script>
var timerID;

        window.onload = function() {

        document.getElementById('execute').click();

        }
var timerID;



$(document).ready(function () {
    $('#execute').on('click',function(e){
        e.preventDefault();
        updateData();
    });
    $('#stop').on('click',function(e){
        e.preventDefault();
       clearTimeout(timerID); // 타이머 중지
        $('#showtime').html('');
    });
});




function updateData(){
    $.ajax({
      url: "getserver.php?page=<?php echo $page;?>",
      type:"post",
      cache : false,
      success: function(data){ // getserver.php 파일에서 echo 결과값이 data 임
       $('#showtime').html(data);
      }
    });
    timerID = setTimeout("updateData()", 500); // 
}













</script>
  
  
  
  
  
  
  
  

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a class="nav-link" href="../index.php"><img src="./icon.jpg">프로젝트e.com<img src="./icon.jpg"></a>
					</li>

					<li class="nav-item active">
						<a class="nav-link" href="../exchange">거래소</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../wallet">지갑관리</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../txid/">거래내역</a>
					</li>	
				</ul>
				
				<?php
					if(isset($_SESSION['email']))
					{
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link"><?php echo "<b>{$queryinformation['name']}</b>님";?></a>
					</li>
					
					<li class="nav-item active">
						<a class="nav-link" href="../logout.php">로그아웃</a>
					</li>
				</ul>	
				<?php
					}
					else
					{		
				?>
				<ul class="navbar-nav navbar-right">
					<li class="nav-item active">
						<a class="nav-link" href="../login.php">로그인</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="../join.php">회원가입</a>
					</li>
				</ul>
				<?php
					}
				?>
			</div>
			</nav>
				

  <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
	    
        <div class="col-xl-9 mx-auto">

          <p><span id="showtime"></span></p>
		  
		 
 
      </div>
	  
    </div>
	
  </header>

 

 


  <!-- Footer -->
  <footer class="footer bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
          <ul class="list-inline mb-2">
            <li class="list-inline-item">
              <a href="#">소프트웨어공학론</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">김규환 박종훈 강 일 위안펑</a>
            </li>
          </ul>
          <p class="text-muted small mb-4 mb-lg-0" id="execute">&copy; 프로젝트e.com 2020. All Rights Reserved.</p>
        </div>
        <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
          <ul class="list-inline mb-0">
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-facebook fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-twitter-square fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fab fa-instagram fa-2x fa-fw"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

